﻿using BMS_MVC.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace BMS_MVC.Controllers
{
    public class AccountHomeController : Controller
    {
        public static AccountDetails myAccountDetails = null;
        public static UserAccount LoggedInUser = null;
        // GET: AccountHome
        
        public ActionResult LoggedOut()
        {
            return RedirectToAction("LoggedOut", "BMS");
        }
        public ActionResult AccountHomePage(UserAccount user)
        {
            AccountDetails result = null;
            LoggedInUser = user;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                user.Password = "";
                var responseTask = client.GetAsync($"BMS/GetAccDetails?user={user.PhoneNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<AccountDetails>();
                    readTask.Wait();
                    result = readTask.Result;
                    if (result != null)
                    {
                        myAccountDetails = (AccountDetails)result;
                        return View(myAccountDetails);
                    }
                }
            }
            return View();
        }

        public ActionResult AccountHomeView()
        {
            return RedirectToAction("AccountHomePage", LoggedInUser);
            //return View(myAccountDetails);
        }

        public ActionResult RequestForChequeBook()
        {
            return View();
        }
        public ActionResult AddPayee()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddPayee([Bind(Include = "PayeeAccountNo,PayeeName,IFSC,TransactionLimit")]PayeeDetails newPayee)
        {
            newPayee.AccountNo = myAccountDetails.AccountNo;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var postTask = client.GetAsync($"BMS/CheckPayee?accNo={newPayee.PayeeAccountNo}");
                postTask.Wait();
                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<Int32>();
                    readTask.Wait();
                    if (readTask.Result != 0)
                    {
                        using (var client1 = new HttpClient())
                        {
                            client1.BaseAddress = new Uri("http://localhost:63458/api/");
                            var postTask1 = client1.PostAsJsonAsync<PayeeDetails>("BMS/AddPayee", newPayee);
                            postTask1.Wait();
                            var res1 = postTask1.Result;
                            if (res1.IsSuccessStatusCode)
                            {
                                var readTask1 = res1.Content.ReadAsAsync<bool>();
                                readTask1.Wait();
                                if (readTask1.Result)
                                {
                                    return RedirectToAction("ShowPayees", "AccountHome");
                                }
                            }

                            return View(newPayee);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("PayeeAccNo", $"No bank account linked with {newPayee.PayeeAccountNo}");
                    }
                }
            }
            return View(newPayee);
        }

        [HttpGet]
        public ActionResult ShowPayees()
        {
            List<PayeeDetails> payees = new List<PayeeDetails>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetAllPayees?AccountNo={myAccountDetails.AccountNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<PayeeDetails>>();
                    readTask.Wait();
                    payees = readTask.Result;
                    return View(payees);
                }
            }
            return View();
        }


        public ActionResult AddTransaction()
        {
            List<PayeeDetails> payees = new List<PayeeDetails>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetAllPayees?AccountNo={myAccountDetails.AccountNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<PayeeDetails>>();
                    readTask.Wait();
                    payees = readTask.Result;
                 
                    ViewBag.PayeeList = payees;
                    return View(payees);
                }
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult AddTransaction([Bind(Include = "PayeeID,Amount")]TransactionDetails trans)
        {
            trans.AccountNo = myAccountDetails.AccountNo;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var postTask = client.PostAsJsonAsync<TransactionDetails>("BMS/AddTransaction", trans);
                postTask.Wait();
                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<int>();
                    readTask.Wait();
                    if (readTask.Result == 1)
                    {
                        return RedirectToAction("ShowTransactions", "AccountHome");
                    }
                    else if(readTask.Result == -1)
                    {
                        return RedirectToAction("Insufficient", "AccountHome");
                    }
                    else if(readTask.Result == 2)
                    {
                        return RedirectToAction("ExceededTrans", "AccountHome");
                    }
                }
            }
            return View(trans);

        }


        public ActionResult Insufficient()
        {
            return View();
        }

        public ActionResult ExceededTrans()
        {
            return View();
        }


        [HttpGet]
        public ActionResult ShowTransactions()
        {
            List<TransactionDetails> trans = new List<TransactionDetails>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetAllTrans?AccountNo={myAccountDetails.AccountNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<TransactionDetails>>();
                    readTask.Wait();
                    trans = readTask.Result;
                    return View(trans);
                }
            }
            return View();
        }


        public ActionResult ChangePassword()
        {
            return View();
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(string pwdold, string pwdnew, string pwdcheck)
        {
            if (pwdold == "")
            {
                ModelState.AddModelError("pwdold", "Please Enter Old Password");
            }
            if (pwdnew == "")
            {
                ModelState.AddModelError("pwdnew", "Please Enter New Password");
            }
        
            if (pwdcheck == "")
            {
                ModelState.AddModelError("pwdcheck", "Please Enter Password for Confirmation");
            }
            if (pwdold != "" && pwdnew != "" && pwdcheck != "")
            {
                if (pwdnew.Length < 6)
                {
                    ModelState.AddModelError("pwdnew", "Password should contain minimum 6 digits");
                }
                else if (pwdnew != pwdcheck)
                {
                    ModelState.AddModelError("pwdcheck", "Please Enter Password for Confirmation");
                    return View();
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:63458/api/");
                        var responseTask = client.PutAsJsonAsync($"BMS/ChangePassword?loginid={LoggedInUser.UserName}&password={pwdold}&passwordnew={pwdnew}",LoggedInUser);
                        responseTask.Wait();
                        var res = responseTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<bool>();
                            readTask.Wait();
                            if (readTask.Result)
                            {
                                return RedirectToAction("LoggedOut");
                              
                            }
                            else
                            {
                                ModelState.AddModelError("isvalid", "Invalid Password");
                            }
                        }
                    }
                }

            }
            return View();
        }



        [HttpPost]
        public ActionResult RequestForChequeBook([Bind(Include = "Pages, Address")]ChequeBookRequest newRequest)
        {
            newRequest.AccountNo = myAccountDetails.AccountNo;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var postTask = client.PostAsJsonAsync<ChequeBookRequest>("BMS/AddChequeBookRequest", newRequest);
                postTask.Wait();
                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<bool>();
                    readTask.Wait();
                    if (readTask.Result)
                    {
                         return RedirectToAction("ShowChequeBookRequests", "AccountHome");
                      
                    }
                }
            }
            return View(newRequest);
        }

        [HttpGet]
        public ActionResult ShowChequeBookRequests()
        {
            List<ChequeBookRequest> payees = new List<ChequeBookRequest>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetChequeBookRequest?AccountNo={myAccountDetails.AccountNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<ChequeBookRequest>>();
                    readTask.Wait();
                    payees = readTask.Result;
                    return View(payees);
                }
            }
            return View();
        }


        public ActionResult TakeLoan()
        {
            List<LoanTypeTable> loanType = new List<LoanTypeTable>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetLoanTypes");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<LoanTypeTable>>();
                    readTask.Wait();
                    loanType = readTask.Result;
                    ViewBag.TypeId = new SelectList(loanType , "TypeId", "LoanType");
                    return View();
                }
            }
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult TakeLoan([Bind(Include = "PrincipleAmount, TypeId")]LoanDetails loan)
            {
            loan.AccountNo = myAccountDetails.AccountNo;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var postTask = client.GetAsync($"BMS/CheckLoan?accNo={loan.AccountNo}");
                postTask.Wait();
                var res = postTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<Int32>();
                    readTask.Wait();
                    if (readTask.Result == 0)
                    {
                        using (var client0 = new HttpClient())
                        {
                            client0.BaseAddress = new Uri("http://localhost:63458/api/");
                            var postTask0 = client0.GetAsync($"BMS/GetInterestRate?typeId={loan.TypeId}");
                            postTask0.Wait();
                            var res0 = postTask0.Result;
                            if (res0.IsSuccessStatusCode)
                            {
                                var InterestRate = res0.Content.ReadAsAsync<int>();
                                InterestRate.Wait();
                                loan.LoanBalance = ((InterestRate.Result * loan.PrincipleAmount) / 100) + loan.PrincipleAmount;
                                ViewBag.LoanBalance = loan.LoanBalance;
                            }

                        }
                        using (var client1 = new HttpClient())
                            {

                                client1.BaseAddress = new Uri("http://localhost:63458/api/");
                                var postTask1 = client1.PostAsJsonAsync<LoanDetails>("BMS/TakeLoan", loan);
                                postTask1.Wait();
                                var res1 = postTask1.Result;
                                if (res1.IsSuccessStatusCode)
                                {
                                    var readTask1 = res1.Content.ReadAsAsync<bool>();
                                    readTask1.Wait();
                                    if (readTask1.Result)
                                    {
                                   // return RedirectToAction("ShowAlert", "AccountHome");
                                    return RedirectToAction("ShowLoanDetails", "AccountHome");                                   
                                    }
                                }

                                return View(loan);
                            }
                        }
                    else
                     {
                        return RedirectToAction("ShowLoanDetails", "AccountHome");
                    }
                    }
                }
                return View(loan);
            }


        [HttpGet]
        public ActionResult ShowLoanDetails()
        {
            List<LoanDetails> loans = new List<LoanDetails>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("http://localhost:63458/api/");
                var responseTask = client.GetAsync($"BMS/GetLoanDetails?AccountNo={myAccountDetails.AccountNo}");
                responseTask.Wait();
                var res = responseTask.Result;
                if (res.IsSuccessStatusCode)
                {
                    var readTask = res.Content.ReadAsAsync<List<LoanDetails>>();
                    readTask.Wait();
                    loans = readTask.Result;
                    return View(loans);
                }
            }
            return View();
        }



    }


}