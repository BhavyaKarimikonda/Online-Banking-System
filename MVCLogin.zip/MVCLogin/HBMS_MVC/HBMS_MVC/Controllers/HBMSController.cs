﻿using HBMS_MVC.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;


namespace HBMS_MVC.Controllers
{
    public class HBMSController : Controller
    {
        public static UserAccount LoggedInUser=null;

        // GET: HBMS
        public ActionResult Home()
        {
            return View();
        }

        public ActionResult UserAccount()
        {
            return View(LoggedInUser);
        }

        public ActionResult RegisterUser()
        {
            UserAccount user = new UserAccount();
            return View(user);
        }
                

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult RegisterUser([Bind(Include = "UserId,UserName,Email,PhoneNo,Name,Password")]UserAccount user,string Confirm_Password)
        {
            if (ModelState.IsValid)
            {
                int result = 0;
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:63458/api/");
                    var responseTask = client.GetAsync($"HBMS/UserAlreadyExist?username={user.UserName}&phoneno={user.PhoneNo}");
                    responseTask.Wait();

                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<Int32>();
                        readTask.Wait();
                        result = readTask.Result;
                    }
                }
                if (user.Password != Confirm_Password)
                {
                    ModelState.AddModelError("Confirm_Password", "Does Not Match With Password");
                }
                else if (result == 0)
                {
                    using (var client = new HttpClient())
                    {
                        client.BaseAddress = new Uri("http://localhost:63458/api/");
                        var postTask = client.GetAsync($"HBMS/CheckPhoneNumber?phoneno={user.PhoneNo}");
                        postTask.Wait();

                        var res = postTask.Result;
                        if (res.IsSuccessStatusCode)
                        {
                            var readTask = res.Content.ReadAsAsync<Int32>();
                            readTask.Wait();
                            if (readTask.Result != 0)
                            {
                                using (var client1 = new HttpClient())
                                {
                                    client1.BaseAddress = new Uri("http://localhost:63458/api/");
                                    var postTask1 = client.PostAsJsonAsync<UserAccount>("HBMS/PostUser", user);
                                    postTask1.Wait();

                                    var res1 = postTask1.Result;
                                    if (res1.IsSuccessStatusCode)
                                    {
                                        var readTask1 = res1.Content.ReadAsAsync<bool>();
                                        readTask1.Wait();
                                        if (readTask1.Result)
                                        {
                                            return RedirectToAction("Login", "HBMS");
                                        }
                                    }
                                }
                            }
                            else
                            {
                                ModelState.AddModelError("PhoneNo", $"No bank account linked with {user.PhoneNo}");
                            }
                        }
                    }
                   
                }
                if (result % 10 == 1)
                {
                    ModelState.AddModelError("UserName", "Entered UserName Not Available");
                }
                
                if (result / 100 == 1)
                {
                    ModelState.AddModelError("PhoneNo", $"An account already exists with {user.PhoneNo}");
                }
                
            }
            return View(user);
        }

        public ActionResult Login()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(string loginid,string password)
        {
            UserAccount result = null;
            if (loginid == "")
            {
                ModelState.AddModelError("loginid", $"Please Enter UserName/Email ID");
            }
            if (password == "")
            {
                ModelState.AddModelError("password", $"Please Enter Password");
            }
            if (loginid!="" && password!="")
            {
                
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://localhost:63458/api/");
                    var responseTask = client.GetAsync($"HBMS/Login?loginid={loginid}&password={password}");
                    responseTask.Wait();
                    var res = responseTask.Result;
                    if (res.IsSuccessStatusCode)
                    {
                        var readTask = res.Content.ReadAsAsync<UserAccount>();
                        readTask.Wait();
                        result = readTask.Result;
                        if (result!=null)
                        {
                            LoggedInUser = (UserAccount)result;
                            return RedirectToAction("AccountHomePage","AccountHome",LoggedInUser);
                        }
                        else
                        {
                            ModelState.AddModelError("isvalid","Invalid Login ID/Password");
                        }
                    }
                }
            }
            ViewBag.UserName = loginid;
            ViewBag.Password = "";
            return View();
        }

        public ActionResult LoggedIn()
        {
            if(LoggedInUser!=null)
            {
                return View(LoggedInUser);
            }
            return View();
        }

        public ActionResult LoggedOut()
        {

            LoggedInUser = null;
            return View();
        }

        public ActionResult Contact()
        {
            return View();
        }
    }
}