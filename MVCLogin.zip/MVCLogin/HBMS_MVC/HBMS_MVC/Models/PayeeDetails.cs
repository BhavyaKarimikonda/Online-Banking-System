﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace HBMS_MVC.Models
{
    public class PayeeDetails
    {
        public int PayeeID { get; set; }
        public string AccountNo { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [StringLength(15, MinimumLength = 11, ErrorMessage = "Must be at least 11 characters long.")]
        public string PayeeAccountNo { get; set; }

        [Display(Name = "Payee Name")]
        [Required(ErrorMessage = "(Required)")]
        [StringLength(40)]
        [RegularExpression("^[A-Za-z0-9]+$")]
        public string PayeeName { get; set; }

        [Required(ErrorMessage = "(Required)")]
        public string IFSC { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Must be an integer")]
        public Int64 TransactionLimit { get; set; }       
    }
}