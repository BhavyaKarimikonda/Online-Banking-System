﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BMS_MVC.Models
{
    public class LoanTypeTable
    {
        public int TypeId { get; set; }
        public string LoanType { get; set; }
        public int InterestRate { get; set; }
    }
}