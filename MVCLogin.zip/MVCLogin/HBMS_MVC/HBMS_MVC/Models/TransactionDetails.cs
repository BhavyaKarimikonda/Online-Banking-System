﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BMS_MVC.Models
{
    public class TransactionDetails
    {
        public int TransactionID { get; set; }
        public string AccountNo { get; set; }
        public int PayeeID { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [Range(1,1000000,ErrorMessage="Must be positive num")]
        public Int64 Amount { get; set; }      
    }
}