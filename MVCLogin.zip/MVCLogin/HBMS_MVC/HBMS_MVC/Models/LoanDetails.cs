﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBMS_MVC.Models
{
    public class LoanDetails
    {
        public Int64 LoanAccountNo { get; set; }
        public string AccountNo { get; set; }
        public Int64 LoanBalance { get; set; }
        public Int64 PrincipleAmount { get; set; }
        public int TypeId { get; set; }
    }
}