﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BMS_WebAPI.Models
{
    public class TransactionDetails
    {
        public int TransactionID { get; set; }
        public string AccountNo { get; set; }
        public int PayeeID { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Must be an integer")]
        public Int64 Amount { get; set; }
    }
}