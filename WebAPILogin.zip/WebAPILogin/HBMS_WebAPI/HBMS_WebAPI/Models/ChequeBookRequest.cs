﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace BMS_WebAPI.Models
{
    public class ChequeBookRequest
    {
        public int RequestID { get; set; }
        public string AccountNo { get; set; }

        [Required(ErrorMessage = "(Required)")]
        [RegularExpression("^[0-9]+$", ErrorMessage = "Must be an integer")]
        public int Pages { get; set; }

        [Required(ErrorMessage = "(Required)")]
        public string Address { get; set; }
    }
}