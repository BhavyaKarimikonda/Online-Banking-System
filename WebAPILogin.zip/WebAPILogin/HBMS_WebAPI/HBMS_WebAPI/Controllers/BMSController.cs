﻿using BMS_WebAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace BMS_WebAPI.Controllers
{
    public class BMSController : ApiController
    {
        static SqlConnection conn = new SqlConnection("Data Source=NDAMSSQL\\SQLILEARN;Initial Catalog=Training_13Aug19_Pune;User ID=sqluser;Password=sqluser");  //Connection String
        static SqlCommand cmd;     //Will be used to store and execute command
        static SqlDataReader dr;


        [HttpGet]
        public int UserAlreadyExist(string username, string phoneno)
        {
            int result = 0;
            try
            {
                cmd = new SqlCommand("BMS.UserAlreadyExist", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@phoneno", phoneno);
                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }

        [HttpGet]
        public int CheckPhoneNumber(string phoneno)
        {
            int result = 0;
            try
            {
                cmd = new SqlCommand("BMS.CheckPhoneNumber", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@phoneno", phoneno);
                conn.Open();
                result = (int)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }


        [HttpPost]
        public bool PostUser(UserAccount user) //Insert
        {
            bool registered = false;
            try
            {
                cmd = new SqlCommand("BMS.RegisterUser", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@username", user.UserName);
                cmd.Parameters.AddWithValue("@email", user.Email);
                cmd.Parameters.AddWithValue("@phoneno", user.PhoneNo);
                cmd.Parameters.AddWithValue("@name", user.Name);
                cmd.Parameters.AddWithValue("@password", user.Password);

                conn.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    registered = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return registered;
        }
        [HttpGet]
        public UserAccount Login(string loginid, string password)
        {
            UserAccount loggedin = new UserAccount();
            try
            {
                cmd = new SqlCommand("BMS.VerifyLogin", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@loginid", loginid);
                cmd.Parameters.AddWithValue("@password", password);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return null;
                loggedin.UserID = (int)reader[0];
                loggedin.UserName = (string)reader[1];
                loggedin.Email = (string)reader[2];
                loggedin.PhoneNo = (string)reader[3];
                loggedin.Name = (string)reader[4];
                loggedin.Password = null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            if (loggedin.UserName == null)
                return null;
            return loggedin;

        }



        [HttpGet]
        public AccountDetails GetAccDetails(string user)
        {
            AccountDetails mydetails = new AccountDetails();
            try
            {
                cmd = new SqlCommand("BMS.ViewDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PhoneNo", user);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (!reader.Read())
                    return null;
                mydetails.AccountNo = (string)reader[0];
                mydetails.Balance = Convert.ToInt64(reader[1]);
                mydetails.PhoneNo = (string)reader[2];
                mydetails.Name = (string)reader[3];
                mydetails.Email = (string)reader[4];
                mydetails.IFSC = (string)reader[5]; 
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return mydetails;

        }


        [HttpPut]
        public bool ChangePassword(UserAccount user, string password, string passwordnew)
        {
            bool changed = false;
            try
            {
                cmd = new SqlCommand("BMS.ChangePassword", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@loginid", user.UserName);
                cmd.Parameters.AddWithValue("@password", password);
                cmd.Parameters.AddWithValue("@passwordnew", passwordnew);
                conn.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    changed = true;
                }
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return changed;
        }

        [HttpGet]
        public int CheckPayee(string accNo)
        {
            int result = 0;
            try
            {
                cmd = new SqlCommand("BMS.CheckPayee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@PayeeAccountNo", accNo);
                conn.Open();
                result = (int)cmd.ExecuteScalar();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }



        [HttpPost]
        public bool AddPayee(PayeeDetails payee) //Insert
        {
            bool pregistered = false;
            try
            {
                cmd = new SqlCommand("BMS.AddPayee", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", payee.AccountNo);
                cmd.Parameters.AddWithValue("@PayeeAccountNo", payee.PayeeAccountNo);
                cmd.Parameters.AddWithValue("@PayeeName", payee.PayeeName);
                cmd.Parameters.AddWithValue("@IFSC", payee.IFSC);
                cmd.Parameters.AddWithValue("@TransactionLimit", payee.TransactionLimit);
                conn.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    pregistered = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return pregistered;
        }

        [HttpGet]
        public List<PayeeDetails> GetAllPayees(string AccountNo)
        {
            List<PayeeDetails> payees = new List<PayeeDetails>();
            try
            {
                cmd = new SqlCommand("BMS.ViewPayeeDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                
                while(reader.Read())
                {
                    PayeeDetails pd = new PayeeDetails();
                    pd.PayeeID = (int)reader[0];
                    pd.AccountNo = (string)reader[1];
                    pd.PayeeAccountNo = (string)reader[2];
                    pd.PayeeName = (string)reader[3];
                    pd.IFSC = (string)reader[4];
                    pd.TransactionLimit = Convert.ToInt64(reader[5]);
                    payees.Add(pd);
                    
                }                
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return payees;
        }


        [HttpPost]
        public bool AddChequeBookRequest(ChequeBookRequest newRequest) //Insert
        {
            bool pregistered = false;
            try
            {
                cmd = new SqlCommand("BMS.RequestingCB", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", newRequest.AccountNo);
                cmd.Parameters.AddWithValue("@Pages", newRequest.Pages);
                cmd.Parameters.AddWithValue("@Address", newRequest.Address);
                conn.Open();
                int result = cmd.ExecuteNonQuery();
                if (result > 0)
                {
                    pregistered = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return pregistered;
        }



        [HttpGet]
        public List<ChequeBookRequest> GetChequeBookRequest(string AccountNo)
        {
            List<ChequeBookRequest> chq = new List<ChequeBookRequest>();
            try
            {
                cmd = new SqlCommand("BMS.GetChequeBookRequests", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ChequeBookRequest pd = new ChequeBookRequest();
                    pd.RequestID = (int)reader[0];
                    pd.AccountNo = (string)reader[1];
                    pd.Pages = (int)reader[2];
                    pd.Address = (string)reader[3];
                    chq.Add(pd);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return chq;
        }


        [HttpPost]
        public int AddTransaction(TransactionDetails newTrans) //Insert
        {
            int pregistered = 0;
            try
            {
                if (GetBalance(newTrans.AccountNo) >= newTrans.Amount)
                {
                    cmd = new SqlCommand("BMS.GetTransLimit", conn);
                    cmd.CommandType = CommandType.StoredProcedure;  
                    cmd.Parameters.AddWithValue("@PayeeID", newTrans.PayeeID);
                    conn.Open();
                    Int64 result =  Convert.ToInt64(cmd.ExecuteScalar());
                    if (result > newTrans.Amount)
                    {

                        cmd = new SqlCommand("BMS.Transactions", conn);
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@AccountNo", newTrans.AccountNo);
                        cmd.Parameters.AddWithValue("@PayeeID", newTrans.PayeeID);
                        cmd.Parameters.AddWithValue("@Amount", newTrans.Amount);
                        int result2 = cmd.ExecuteNonQuery();
                        if (result2 > 0)

                        {
                            pregistered = 1;
                        }
                    }
                    else
                    {
                        pregistered = 2;
                    }
                }
                else
                {
                    //throw new Exception("Insufficient Funds");
                    pregistered = -1;
                }
                }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return pregistered;
        

        }


        public Int64 GetBalance(string AccountNo) 
        {
            Int64 balance = 0;
            try
            {

                cmd = new SqlCommand("BMS.GetBalance", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
                conn.Open();
                 balance = Convert.ToInt64(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return balance;
        }


        [HttpGet]
        public List<TransactionDetails> GetAllTrans(string AccountNo)
        {
            List<TransactionDetails> chq = new List<TransactionDetails>();
            try
            {
                cmd = new SqlCommand("BMS.GetTransactions", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    TransactionDetails pd = new TransactionDetails();
                    pd.TransactionID = (int)reader[0];
                    pd.AccountNo = (string)reader[1];
                    pd.PayeeID = (int)reader[2];
                    pd.Amount = Convert.ToInt64(reader[3]);
                    chq.Add(pd);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return chq;
        }


        [HttpGet]
        public int CheckLoan(string accNo)
        {
            int result = 0;
            try
            {
                cmd = new SqlCommand("BMS.CheckLoan", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", accNo);
                conn.Open();
                result = Convert.ToInt32(cmd.ExecuteScalar());
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }

            return result;
        }


        [HttpGet]
        public List<LoanTypeTable> GetLoanTypes()
        {
            List<LoanTypeTable> payees = new List<LoanTypeTable>();
            try
            {
                cmd = new SqlCommand("BMS.GetLoanTypes", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    LoanTypeTable pd = new LoanTypeTable();
                    pd.TypeId = (int)reader[0];
                    pd.LoanType = (string)reader[1];
                    pd.InterestRate = (int)reader[2];
                    payees.Add(pd);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return payees;
        }

        [HttpGet]
        public int GetInterestRate(int typeId)
        {
            int InterestRate =0;
            try
            {
                cmd = new SqlCommand("BMS.GetInterestRate", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TypeId", typeId);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    InterestRate = (int)reader[0];
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return  InterestRate;
        }


        [HttpPost]
        public bool TakeLoan(LoanDetails newLoan) //Insert
        {
            bool pregistered = false;
            try
            {
                    cmd = new SqlCommand("BMS.TakeLoan", conn);
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@AccountNo", newLoan.AccountNo);
                    cmd.Parameters.AddWithValue("@LoanBalance", newLoan.LoanBalance);
                    cmd.Parameters.AddWithValue("@PrincipleAmount", newLoan.PrincipleAmount);
                    cmd.Parameters.AddWithValue("@TypeId", newLoan.TypeId);
                     conn.Open();
                    int result = cmd.ExecuteNonQuery();
                    if (result > 0)
                    {
                        pregistered = true;
                    }               
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return pregistered;
        }


        public List<LoanDetails> GetLoanDetails(string AccountNo)
        {
            List<LoanDetails> chq = new List<LoanDetails>();
            try
            {
                cmd = new SqlCommand("BMS.GetLoanDetails", conn);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNo", AccountNo);
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    LoanDetails pd = new LoanDetails();
                    pd.LoanAccountNo = Convert.ToInt64(reader[0]);
                    pd.AccountNo = (string)reader[1];
                    pd.LoanBalance = Convert.ToInt64(reader[2]);
                    pd.PrincipleAmount = Convert.ToInt64(reader[3]);
                    pd.TypeId = (int)reader[4];
                    chq.Add(pd);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return chq;
        }
    }
}
